# Luc DEGUENON — Backend

Backend indépendant du frontend React.

- Frontend: Vercel
- Backend: Render
- Database: MongoDB Atlas
- Images/media: Cloudinary
- API: REST / JSON
- Auth: JWT dans cookie HttpOnly + protection CSRF
- Audit: MongoDB `auditlogs`

## 1. Installation

```bash
npm install
```

Créer `.env` à partir de `.env.example`.

Ne jamais pousser `.env` sur GitHub.

## 2. Variables Render

Configurer dans Render:

- `NODE_ENV=production`
- `PORT` (Render peut le fournir; 10000 fonctionne aussi)
- `FRONTEND_URL=https://TON-FRONTEND.vercel.app`
- `MONGODB_URI=...`
- `MONGODB_DB_NAME=luc_deguenon_portfolio`
- `JWT_SECRET=...`
- `JWT_EXPIRES_IN=8h`
- `COOKIE_NAME=luc_admin_session`
- `CSRF_COOKIE_NAME=luc_csrf`
- `CLOUDINARY_CLOUD_NAME=dutqyzet`
- `CLOUDINARY_API_KEY=...`
- `CLOUDINARY_API_SECRET=...`
- `CLOUDINARY_FOLDER=luc-deguenon`
- `MAX_UPLOAD_MB=8`

Les secrets MongoDB, JWT et Cloudinary restent uniquement dans Render.

## 3. Premier superadmin

En local ou temporairement via un shell sécurisé:

```bash
ADMIN_NAME="Luc DEGUENON" ADMIN_EMAIL="..." ADMIN_PASSWORD="..." npm run seed:admin
```

Ne pas mettre le mot de passe dans GitHub.

## 4. Démarrage

```bash
npm run dev
```

Production:

```bash
npm start
```

## 5. API

Public:
- `GET /`
- `GET /api/health`
- `GET /api/profile`
- `GET /api/projects`
- `GET /api/skills`
- `GET /api/services`
- `GET /api/media`
- `GET /api/settings`

Admin:
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/auth/csrf`
- `POST /api/auth/logout`
- CRUD `/api/projects`
- CRUD `/api/skills`
- CRUD `/api/services`
- CRUD `/api/media`
- CRUD `/api/profile`
- `GET /api/audit`
- `GET /api/admin`

## Sécurité

Le backend:
- refuse les origines CORS non autorisées;
- utilise Helmet;
- limite les requêtes;
- limite fortement les tentatives de login;
- valide les entrées avec Zod;
- utilise des cookies HttpOnly pour la session;
- ajoute une protection CSRF aux méthodes d'écriture;
- limite les uploads et leurs MIME types;
- ne retourne pas les secrets;
- journalise les actions sensibles;
- permet au superadmin de consulter les audits;
- applique le principe de permissions.

Avant la production, activer HTTPS uniquement et vérifier les domaines Vercel/Render.
