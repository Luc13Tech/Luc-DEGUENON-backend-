import mongoose from "mongoose";
import { env } from "./env.js";

export async function connectDatabase() {
  await mongoose.connect(env.mongodbUri, {
    dbName: env.mongodbDbName,
    serverSelectionTimeoutMS: 10000
  });

  console.log("MongoDB Atlas connected.");
}

export function databaseReady() {
  return mongoose.connection.readyState === 1;
}
