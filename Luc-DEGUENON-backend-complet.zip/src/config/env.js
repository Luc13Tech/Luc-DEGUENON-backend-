const required = [
  "MONGODB_URI",
  "JWT_SECRET",
  "CLOUDINARY_CLOUD_NAME",
  "CLOUDINARY_API_KEY",
  "CLOUDINARY_API_SECRET",
  "FRONTEND_URL"
];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
}

if (process.env.JWT_SECRET.length < 64) {
  throw new Error("JWT_SECRET must be at least 64 characters.");
}

export const env = {
  nodeEnv: process.env.NODE_ENV || "development",
  port: Number(process.env.PORT || 5000),
  frontendUrl: process.env.FRONTEND_URL.replace(/\/$/, ""),
  mongodbUri: process.env.MONGODB_URI,
  mongodbDbName: process.env.MONGODB_DB_NAME || "luc_deguenon_portfolio",
  jwtSecret: process.env.JWT_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "8h",
  cookieName: process.env.COOKIE_NAME || "luc_admin_session",
  csrfCookieName: process.env.CSRF_COOKIE_NAME || "luc_csrf",
  cloudinaryFolder: process.env.CLOUDINARY_FOLDER || "luc-deguenon",
  maxUploadMb: Number(process.env.MAX_UPLOAD_MB || 8)
};
