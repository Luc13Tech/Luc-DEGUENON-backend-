import Profile from "../models/Profile.js";
import { profileSchema } from "../validators/profile.validator.js";
import { writeAudit } from "../services/audit.service.js";

export async function getPublic(req, res) {
  const item = await Profile.findOne({ key: "main", published: true }).lean();
  res.json({ item: item || null });
}

export async function getAdmin(req, res) {
  const item = await Profile.findOne({ key: "main" }).lean();
  res.json({ item: item || null });
}

export async function upsert(req, res) {
  const data = profileSchema.parse(req.body);
  const item = await Profile.findOneAndUpdate(
    { key: "main" },
    { ...data, key: "main" },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );

  await writeAudit({
    req,
    action: "PROFILE_UPDATED",
    resource: "PROFILE",
    resourceId: item._id,
    details: { changedFields: Object.keys(data) }
  });

  res.json({ item });
}
