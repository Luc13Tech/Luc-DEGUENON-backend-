import Project from "../models/Project.js";
import { projectSchema } from "../validators/project.validator.js";
import { writeAudit } from "../services/audit.service.js";

export async function listPublic(req, res) {
  const items = await Project.find({
    deleted: false,
    published: true
  }).sort({ order: 1, createdAt: -1 }).lean();

  res.json({ items });
}

export async function listAdmin(req, res) {
  const includeDeleted = req.query.includeDeleted === "true";
  const filter = includeDeleted ? {} : { deleted: false };

  const items = await Project.find(filter)
    .sort({ order: 1, createdAt: -1 })
    .lean();

  res.json({ items });
}

export async function create(req, res) {
  const data = projectSchema.parse(req.body);
  const item = await Project.create(data);

  await writeAudit({
    req,
    action: "PROJECT_CREATED",
    resource: "PROJECT",
    resourceId: item._id,
    details: { title: item.title }
  });

  res.status(201).json({ item });
}

export async function update(req, res) {
  const data = projectSchema.partial().parse(req.body);
  const item = await Project.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    data,
    { new: true, runValidators: true }
  );

  if (!item) return res.status(404).json({ message: "Project not found." });

  await writeAudit({
    req,
    action: "PROJECT_UPDATED",
    resource: "PROJECT",
    resourceId: item._id,
    details: { changedFields: Object.keys(data) }
  });

  res.json({ item });
}

export async function softDelete(req, res) {
  const item = await Project.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    {
      deleted: true,
      deletedAt: new Date(),
      deletedBy: req.admin._id,
      published: false
    },
    { new: true }
  );

  if (!item) return res.status(404).json({ message: "Project not found." });

  await writeAudit({
    req,
    action: "PROJECT_SOFT_DELETED",
    resource: "PROJECT",
    resourceId: item._id,
    details: { title: item.title }
  });

  res.json({ item });
}

export async function restore(req, res) {
  const item = await Project.findOneAndUpdate(
    { _id: req.params.id, deleted: true },
    {
      deleted: false,
      deletedAt: null,
      deletedBy: null
    },
    { new: true }
  );

  if (!item) return res.status(404).json({ message: "Deleted project not found." });

  await writeAudit({
    req,
    action: "PROJECT_RESTORED",
    resource: "PROJECT",
    resourceId: item._id
  });

  res.json({ item });
}
