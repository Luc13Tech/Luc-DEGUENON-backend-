import bcrypt from "bcryptjs";
import { z } from "zod";
import Admin from "../models/Admin.js";
import { env } from "../config/env.js";
import { createAdminToken } from "../services/token.service.js";
import { issueCsrfCookie } from "../middleware/security.js";
import { writeAudit } from "../services/audit.service.js";

const loginSchema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(8).max(128)
});

function cookieOptions() {
  return {
    httpOnly: true,
    secure: env.nodeEnv === "production",
    sameSite: env.nodeEnv === "production" ? "none" : "lax",
    maxAge: 8 * 60 * 60 * 1000,
    path: "/"
  };
}

export async function login(req, res) {
  try {
    const data = loginSchema.parse(req.body);
    const email = data.email.toLowerCase();

    const admin = await Admin.findOne({ email }).select("+passwordHash");

    if (!admin || !admin.active) {
      await writeAudit({
        req,
        action: "LOGIN_FAILED",
        resource: "AUTH",
        success: false,
        details: { reason: "invalid_credentials", email }
      });
      return res.status(401).json({ message: "Invalid credentials." });
    }

    if (admin.lockedUntil && admin.lockedUntil > new Date()) {
      return res.status(423).json({ message: "Account temporarily locked." });
    }

    const valid = await bcrypt.compare(data.password, admin.passwordHash);

    if (!valid) {
      admin.failedLoginAttempts += 1;

      if (admin.failedLoginAttempts >= 5) {
        admin.lockedUntil = new Date(Date.now() + 15 * 60 * 1000);
        admin.failedLoginAttempts = 0;
      }

      await admin.save();

      await writeAudit({
        req,
        action: "LOGIN_FAILED",
        resource: "AUTH",
        success: false,
        details: { reason: "invalid_password", email }
      });

      return res.status(401).json({ message: "Invalid credentials." });
    }

    admin.failedLoginAttempts = 0;
    admin.lockedUntil = null;
    admin.lastLoginAt = new Date();
    await admin.save();

    const token = await createAdminToken(admin);
    res.cookie(env.cookieName, token, cookieOptions());
    issueCsrfCookie(res);

    await writeAudit({
      req,
      action: "LOGIN_SUCCESS",
      resource: "AUTH"
    });

    return res.json({
      authenticated: true,
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role
      }
    });
  } catch (error) {
    if (error?.name === "ZodError") {
      return res.status(400).json({ message: "Invalid login data." });
    }
    console.error(error);
    return res.status(500).json({ message: "Server error." });
  }
}

export async function me(req, res) {
  res.json({
    authenticated: true,
    admin: {
      id: req.admin._id,
      name: req.admin.name,
      email: req.admin.email,
      role: req.admin.role,
      lastLoginAt: req.admin.lastLoginAt
    }
  });
}

export async function csrf(req, res) {
  issueCsrfCookie(res);
  res.json({ ok: true });
}

export async function logout(req, res) {
  await writeAudit({ req, action: "LOGOUT", resource: "AUTH" });

  res.clearCookie(env.cookieName, cookieOptions());
  res.clearCookie(env.csrfCookieName, {
    secure: env.nodeEnv === "production",
    sameSite: env.nodeEnv === "production" ? "none" : "lax",
    path: "/"
  });

  res.json({ authenticated: false });
}
