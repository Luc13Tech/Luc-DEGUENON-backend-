import Service from "../models/Service.js";
import { serviceSchema } from "../validators/service.validator.js";
import { writeAudit } from "../services/audit.service.js";

export async function listPublic(req, res) {
  const items = await Service.find({ deleted: false, published: true })
    .sort({ order: 1, createdAt: -1 }).lean();
  res.json({ items });
}

export async function listAdmin(req, res) {
  const items = await Service.find({ deleted: false })
    .sort({ order: 1, createdAt: -1 }).lean();
  res.json({ items });
}

export async function create(req, res) {
  const item = await Service.create(serviceSchema.parse(req.body));
  await writeAudit({ req, action: "SERVICE_CREATED", resource: "SERVICE", resourceId: item._id });
  res.status(201).json({ item });
}

export async function update(req, res) {
  const data = serviceSchema.partial().parse(req.body);
  const item = await Service.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    data,
    { new: true, runValidators: true }
  );
  if (!item) return res.status(404).json({ message: "Service not found." });
  await writeAudit({ req, action: "SERVICE_UPDATED", resource: "SERVICE", resourceId: item._id, details: { changedFields: Object.keys(data) } });
  res.json({ item });
}

export async function softDelete(req, res) {
  const item = await Service.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    { deleted: true, deletedAt: new Date(), deletedBy: req.admin._id, published: false },
    { new: true }
  );
  if (!item) return res.status(404).json({ message: "Service not found." });
  await writeAudit({ req, action: "SERVICE_SOFT_DELETED", resource: "SERVICE", resourceId: item._id });
  res.json({ item });
}
