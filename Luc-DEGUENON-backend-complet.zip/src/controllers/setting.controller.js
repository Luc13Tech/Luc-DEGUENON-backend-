import Setting from "../models/Setting.js";
import { settingSchema } from "../validators/setting.validator.js";
import { writeAudit } from "../services/audit.service.js";

export async function listPublic(req, res) {
  const items = await Setting.find({ public: true }).select("-__v").lean();
  res.json({ items });
}

export async function listAdmin(req, res) {
  const items = await Setting.find({}).sort({ key: 1 }).lean();
  res.json({ items });
}

export async function upsert(req, res) {
  const data = settingSchema.parse(req.body);

  const item = await Setting.findOneAndUpdate(
    { key: data.key },
    data,
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );

  await writeAudit({
    req,
    action: "SETTING_UPDATED",
    resource: "SETTING",
    resourceId: item._id,
    details: { key: item.key }
  });

  res.json({ item });
}

export async function remove(req, res) {
  const item = await Setting.findOneAndDelete({ key: req.params.key });

  if (!item) return res.status(404).json({ message: "Setting not found." });

  await writeAudit({
    req,
    action: "SETTING_DELETED",
    resource: "SETTING",
    resourceId: item._id,
    details: { key: item.key }
  });

  res.json({ success: true });
}
