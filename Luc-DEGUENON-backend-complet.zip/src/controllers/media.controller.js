import Media from "../models/Media.js";
import { uploadImageBuffer, deleteCloudinaryImage } from "../config/cloudinary.js";
import { env } from "../config/env.js";
import { writeAudit } from "../services/audit.service.js";

export async function list(req, res) {
  const items = await Media.find({ deleted: false })
    .sort({ createdAt: -1 }).lean();
  res.json({ items });
}

export async function upload(req, res) {
  if (!req.file) return res.status(400).json({ message: "Image is required." });

  const result = await uploadImageBuffer(req.file.buffer, {
    folder: env.cloudinaryFolder
  });

  const item = await Media.create({
    url: result.secure_url,
    publicId: result.public_id,
    resourceType: result.resource_type,
    format: result.format,
    width: result.width,
    height: result.height,
    bytes: result.bytes,
    folder: env.cloudinaryFolder,
    alt: req.body.alt || "",
    createdBy: req.admin._id
  });

  await writeAudit({
    req,
    action: "MEDIA_UPLOADED",
    resource: "MEDIA",
    resourceId: item._id,
    details: { publicId: item.publicId, bytes: item.bytes }
  });

  res.status(201).json({ item });
}

export async function update(req, res) {
  const allowed = {};
  if (typeof req.body.alt === "string") allowed.alt = req.body.alt.slice(0, 250);

  const item = await Media.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    allowed,
    { new: true, runValidators: true }
  );

  if (!item) return res.status(404).json({ message: "Media not found." });

  await writeAudit({
    req,
    action: "MEDIA_UPDATED",
    resource: "MEDIA",
    resourceId: item._id,
    details: { changedFields: Object.keys(allowed) }
  });

  res.json({ item });
}

export async function softDelete(req, res) {
  const item = await Media.findOneAndUpdate(
    { _id: req.params.id, deleted: false },
    { deleted: true, deletedAt: new Date(), deletedBy: req.admin._id },
    { new: true }
  );

  if (!item) return res.status(404).json({ message: "Media not found." });

  try {
    await deleteCloudinaryImage(item.publicId);
  } catch (error) {
    console.error("Cloudinary deletion warning:", error.message);
  }

  await writeAudit({
    req,
    action: "MEDIA_DELETED",
    resource: "MEDIA",
    resourceId: item._id,
    details: { publicId: item.publicId }
  });

  res.json({ item });
}
