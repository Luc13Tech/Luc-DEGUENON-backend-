import Admin from "../models/Admin.js";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { writeAudit } from "../services/audit.service.js";

const createSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().email().max(254),
  password: z.string().min(12).max(128),
  role: z.enum(["admin", "superadmin"]).default("admin")
});

export async function listAdmins(req, res) {
  const admins = await Admin.find({})
    .select("-passwordHash")
    .sort({ createdAt: -1 })
    .lean();

  res.json({ items: admins });
}

export async function createAdmin(req, res) {
  const data = createSchema.parse(req.body);
  const exists = await Admin.findOne({ email: data.email.toLowerCase() });

  if (exists) return res.status(409).json({ message: "Email already exists." });

  const passwordHash = await bcrypt.hash(data.password, 12);

  const admin = await Admin.create({
    name: data.name,
    email: data.email.toLowerCase(),
    passwordHash,
    role: data.role
  });

  await writeAudit({
    req,
    action: "ADMIN_CREATED",
    resource: "ADMIN",
    resourceId: admin._id,
    details: { email: admin.email, role: admin.role }
  });

  res.status(201).json({
    id: admin._id,
    name: admin.name,
    email: admin.email,
    role: admin.role
  });
}

export async function deactivateAdmin(req, res) {
  const { id } = req.params;

  if (String(req.admin._id) === id) {
    return res.status(400).json({ message: "You cannot deactivate yourself." });
  }

  const admin = await Admin.findByIdAndUpdate(
    id,
    { active: false },
    { new: true }
  ).select("-passwordHash");

  if (!admin) return res.status(404).json({ message: "Admin not found." });

  await writeAudit({
    req,
    action: "ADMIN_DEACTIVATED",
    resource: "ADMIN",
    resourceId: id
  });

  res.json({ admin });
}
