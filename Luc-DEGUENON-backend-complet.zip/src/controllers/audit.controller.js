import AuditLog from "../models/AuditLog.js";

export async function list(req, res) {
  const page = Math.max(Number(req.query.page || 1), 1);
  const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 100);
  const skip = (page - 1) * limit;

  const filter = {};
  if (req.query.action) filter.action = String(req.query.action);
  if (req.query.resource) filter.resource = String(req.query.resource);

  const [items, total] = await Promise.all([
    AuditLog.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
    AuditLog.countDocuments(filter)
  ]);

  res.json({
    items,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    }
  });
}
