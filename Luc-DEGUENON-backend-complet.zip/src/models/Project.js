import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 180 },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
    category: { type: String, default: "web", trim: true, maxlength: 80 },
    description: { type: String, default: "", maxlength: 5000 },
    technologies: [{ type: String, trim: true, maxlength: 60 }],
    websiteUrl: { type: String, default: "", trim: true, maxlength: 500 },
    githubUrl: { type: String, default: "", trim: true, maxlength: 500 },
    imageUrl: { type: String, default: "" },
    imagePublicId: { type: String, default: "" },
    companyName: { type: String, default: "", trim: true, maxlength: 180 },
    featured: { type: Boolean, default: false, index: true },
    published: { type: Boolean, default: true, index: true },
    order: { type: Number, default: 0, index: true },
    deleted: { type: Boolean, default: false, index: true },
    deletedAt: { type: Date, default: null },
    deletedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin", default: null }
  },
  { timestamps: true }
);

schema.index({ published: 1, deleted: 1, order: 1 });

export default mongoose.model("Project", schema);
