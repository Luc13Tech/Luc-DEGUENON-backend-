import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    actorId: { type: mongoose.Schema.Types.ObjectId, ref: "Admin", default: null, index: true },
    actorEmail: { type: String, default: null, index: true },
    action: { type: String, required: true, index: true },
    resource: { type: String, required: true, index: true },
    resourceId: { type: String, default: null, index: true },
    success: { type: Boolean, default: true },
    ip: { type: String, default: null },
    userAgent: { type: String, default: null },
    details: { type: mongoose.Schema.Types.Mixed, default: {} }
  },
  { timestamps: true }
);

schema.index({ createdAt: -1 });

export default mongoose.model("AuditLog", schema);
