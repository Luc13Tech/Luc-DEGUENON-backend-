import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    key: { type: String, unique: true, default: "main", index: true },
    fullName: { type: String, default: "Luc DEGUENON", maxlength: 180 },
    headline: { type: String, default: "", maxlength: 300 },
    bio: { type: String, default: "", maxlength: 10000 },
    photoUrl: { type: String, default: "" },
    photoPublicId: { type: String, default: "" },
    location: { type: String, default: "", maxlength: 180 },
    email: { type: String, default: "", maxlength: 254 },
    phone: { type: String, default: "", maxlength: 60 },
    githubUrl: { type: String, default: "", maxlength: 500 },
    linkedinUrl: { type: String, default: "", maxlength: 500 },
    published: { type: Boolean, default: true }
  },
  { timestamps: true }
);

export default mongoose.model("Profile", schema);
