import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 180 },
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
    description: { type: String, default: "", maxlength: 5000 },
    features: [{ type: String, trim: true, maxlength: 500 }],
    price: { type: Number, min: 0, default: null },
    priceLabel: { type: String, default: "", maxlength: 100 },
    currency: { type: String, default: "XOF", maxlength: 10 },
    featured: { type: Boolean, default: false },
    published: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
    deleted: { type: Boolean, default: false },
    deletedAt: { type: Date, default: null },
    deletedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin", default: null }
  },
  { timestamps: true }
);

schema.index({ published: 1, deleted: 1, order: 1 });

export default mongoose.model("Service", schema);
