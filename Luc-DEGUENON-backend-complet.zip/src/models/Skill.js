import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 100 },
    category: { type: String, default: "development", trim: true, maxlength: 80 },
    description: { type: String, default: "", maxlength: 1000 },
    icon: { type: String, default: "", maxlength: 100 },
    level: { type: Number, min: 0, max: 100, default: 0 },
    featured: { type: Boolean, default: false },
    published: { type: Boolean, default: true },
    order: { type: Number, default: 0 },
    deleted: { type: Boolean, default: false },
    deletedAt: { type: Date, default: null },
    deletedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin", default: null }
  },
  { timestamps: true }
);

schema.index({ published: 1, deleted: 1, order: 1 });

export default mongoose.model("Skill", schema);
