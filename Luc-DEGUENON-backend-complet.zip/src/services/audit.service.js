import AuditLog from "../models/AuditLog.js";

export async function writeAudit({
  req,
  action,
  resource,
  resourceId = null,
  success = true,
  details = {}
}) {
  try {
    await AuditLog.create({
      actorId: req.admin?._id || null,
      actorEmail: req.admin?.email || null,
      action,
      resource,
      resourceId: resourceId ? String(resourceId) : null,
      success,
      ip: req.ip || null,
      userAgent: req.get("user-agent") || null,
      details
    });
  } catch (error) {
    console.error("Audit log error:", error.message);
  }
}
