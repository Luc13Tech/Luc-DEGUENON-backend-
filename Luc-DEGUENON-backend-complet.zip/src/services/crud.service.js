export function buildPublicFilter(extra = {}) {
  return {
    deleted: false,
    published: true,
    ...extra
  };
}
