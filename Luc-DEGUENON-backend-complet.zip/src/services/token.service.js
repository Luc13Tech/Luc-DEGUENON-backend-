import { SignJWT } from "jose";
import { env } from "../config/env.js";

export async function createAdminToken(admin) {
  return new SignJWT({
    role: admin.role,
    email: admin.email
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(admin._id))
    .setIssuedAt()
    .setExpirationTime(env.jwtExpiresIn)
    .sign(new TextEncoder().encode(env.jwtSecret));
}
