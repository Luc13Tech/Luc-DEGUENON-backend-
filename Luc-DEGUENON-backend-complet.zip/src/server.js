import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { connectDatabase } from "./config/database.js";
import { env } from "./config/env.js";
import { apiLimiter } from "./middleware/security.js";

import healthRoutes from "./routes/health.routes.js";
import authRoutes from "./routes/auth.routes.js";
import adminRoutes from "./routes/admin.routes.js";
import projectRoutes from "./routes/project.routes.js";
import skillRoutes from "./routes/skill.routes.js";
import serviceRoutes from "./routes/service.routes.js";
import profileRoutes from "./routes/profile.routes.js";
import mediaRoutes from "./routes/media.routes.js";
import auditRoutes from "./routes/audit.routes.js";
import settingRoutes from "./routes/setting.routes.js";

const app = express();

app.disable("x-powered-by");
app.set("trust proxy", 1);

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }
  })
);

app.use(
  cors({
    origin(origin, callback) {
      if (!origin || origin === env.frontendUrl) {
        return callback(null, true);
      }
      return callback(new Error("CORS origin denied."));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "X-CSRF-Token"]
  })
);

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));
app.use(cookieParser());
app.use(apiLimiter);

app.get("/", (_req, res) => {
  res.json({
    name: "Luc DEGUENON API",
    status: "online",
    version: "1.0.0"
  });
});

app.use("/api/health", healthRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/skills", skillRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/media", mediaRoutes);
app.use("/api/audit", auditRoutes);
app.use("/api/settings", settingRoutes);

app.use((req, res) => {
  res.status(404).json({ message: "Route not found." });
});

app.use((error, _req, res, _next) => {
  console.error(error);

  if (error?.message === "CORS origin denied.") {
    return res.status(403).json({ message: "Origin denied." });
  }

  if (error?.code === "LIMIT_FILE_SIZE") {
    return res.status(413).json({ message: "File too large." });
  }

  if (error?.message === "Unsupported image type.") {
    return res.status(415).json({ message: error.message });
  }

  if (error?.name === "ZodError") {
    return res.status(400).json({
      message: "Validation failed.",
      errors: error.issues.map((issue) => ({
        path: issue.path,
        message: issue.message
      }))
    });
  }

  if (error?.code === 11000) {
    return res.status(409).json({ message: "A record with this unique value already exists." });
  }

  res.status(500).json({ message: "Internal server error." });
});

connectDatabase()
  .then(() => {
    app.listen(env.port, () => {
      console.log(`Luc DEGUENON API listening on port ${env.port}`);
    });
  })
  .catch((error) => {
    console.error("Startup failed:", error);
    process.exit(1);
  });
