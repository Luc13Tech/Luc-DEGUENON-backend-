import { z } from "zod";
import { slugSchema, urlSchema } from "./common.js";

export const projectSchema = z.object({
  title: z.string().trim().min(1).max(180),
  slug: slugSchema,
  category: z.string().trim().max(80).optional(),
  description: z.string().max(5000).optional(),
  technologies: z.array(z.string().trim().max(60)).max(30).optional(),
  websiteUrl: urlSchema.optional(),
  githubUrl: urlSchema.optional(),
  imageUrl: z.string().max(1000).optional(),
  imagePublicId: z.string().max(500).optional(),
  companyName: z.string().trim().max(180).optional(),
  featured: z.boolean().optional(),
  published: z.boolean().optional(),
  order: z.number().int().min(0).max(100000).optional()
});
