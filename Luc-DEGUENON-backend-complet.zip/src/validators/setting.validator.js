import { z } from "zod";

export const settingSchema = z.object({
  key: z.string().trim().min(1).max(120).regex(/^[a-zA-Z0-9_.-]+$/),
  value: z.any(),
  description: z.string().max(1000).optional(),
  public: z.boolean().optional()
});
