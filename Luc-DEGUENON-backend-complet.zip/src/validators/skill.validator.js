import { z } from "zod";

export const skillSchema = z.object({
  name: z.string().trim().min(1).max(100),
  category: z.string().trim().max(80).optional(),
  description: z.string().max(1000).optional(),
  icon: z.string().max(100).optional(),
  level: z.number().min(0).max(100).optional(),
  featured: z.boolean().optional(),
  published: z.boolean().optional(),
  order: z.number().int().min(0).max(100000).optional()
});
