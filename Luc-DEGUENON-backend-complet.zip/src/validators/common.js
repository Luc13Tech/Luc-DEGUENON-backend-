import { z } from "zod";

export const objectIdSchema = z.string().regex(/^[a-f\d]{24}$/i, "Invalid ID.");

export const urlSchema = z
  .string()
  .trim()
  .max(500)
  .refine((value) => value === "" || /^https?:\/\/.+/i.test(value), "Invalid URL.");

export const slugSchema = z
  .string()
  .trim()
  .min(2)
  .max(180)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Invalid slug.");
