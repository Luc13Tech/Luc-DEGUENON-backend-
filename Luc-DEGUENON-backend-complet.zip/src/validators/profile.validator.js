import { z } from "zod";
import { urlSchema } from "./common.js";

export const profileSchema = z.object({
  fullName: z.string().trim().max(180).optional(),
  headline: z.string().max(300).optional(),
  bio: z.string().max(10000).optional(),
  photoUrl: z.string().max(1000).optional(),
  photoPublicId: z.string().max(500).optional(),
  location: z.string().max(180).optional(),
  email: z.string().email().max(254).or(z.literal("")).optional(),
  phone: z.string().max(60).optional(),
  githubUrl: urlSchema.optional(),
  linkedinUrl: urlSchema.optional(),
  published: z.boolean().optional()
});
