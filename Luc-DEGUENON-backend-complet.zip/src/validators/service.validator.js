import { z } from "zod";
import { slugSchema } from "./common.js";

export const serviceSchema = z.object({
  title: z.string().trim().min(1).max(180),
  slug: slugSchema,
  description: z.string().max(5000).optional(),
  features: z.array(z.string().trim().max(500)).max(50).optional(),
  price: z.number().min(0).nullable().optional(),
  priceLabel: z.string().max(100).optional(),
  currency: z.string().max(10).optional(),
  featured: z.boolean().optional(),
  published: z.boolean().optional(),
  order: z.number().int().min(0).max(100000).optional()
});
