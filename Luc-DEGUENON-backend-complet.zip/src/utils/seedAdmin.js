import "dotenv/config";
import bcrypt from "bcryptjs";
import mongoose from "mongoose";
import Admin from "../models/Admin.js";
import { connectDatabase } from "../config/database.js";

const email = process.env.ADMIN_EMAIL?.toLowerCase();
const password = process.env.ADMIN_PASSWORD;
const name = process.env.ADMIN_NAME || "Luc DEGUENON";

if (!email || !password) {
  console.error("ADMIN_EMAIL and ADMIN_PASSWORD are required.");
  process.exit(1);
}

if (password.length < 12) {
  console.error("ADMIN_PASSWORD must be at least 12 characters.");
  process.exit(1);
}

await connectDatabase();

const existing = await Admin.findOne({ email });

if (existing) {
  console.log("Admin already exists. No changes made.");
  await mongoose.disconnect();
  process.exit(0);
}

const passwordHash = await bcrypt.hash(password, 12);

await Admin.create({
  name,
  email,
  passwordHash,
  role: "superadmin",
  active: true
});

console.log(`Superadmin created: ${email}`);
await mongoose.disconnect();
