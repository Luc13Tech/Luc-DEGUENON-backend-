import { jwtVerify } from "jose";
import Admin from "../models/Admin.js";
import { env } from "../config/env.js";

function secret() {
  return new TextEncoder().encode(env.jwtSecret);
}

export async function requireAdmin(req, res, next) {
  try {
    const token = req.cookies?.[env.cookieName];

    if (!token) {
      return res.status(401).json({ message: "Authentication required." });
    }

    const { payload } = await jwtVerify(token, secret());

    if (!payload.sub) {
      return res.status(401).json({ message: "Invalid session." });
    }

    const admin = await Admin.findById(payload.sub).select("+passwordHash");

    if (!admin || !admin.active) {
      return res.status(401).json({ message: "Account unavailable." });
    }

    req.admin = admin;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired session." });
  }
}

export function requireSuperAdmin(req, res, next) {
  if (req.admin?.role !== "superadmin") {
    return res.status(403).json({ message: "Superadmin permission required." });
  }
  next();
}
