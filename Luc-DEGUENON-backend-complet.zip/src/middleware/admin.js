import { writeAudit } from "../services/audit.service.js";

export function auditAction(action, resource) {
  return async (req, res, next) => {
    res.on("finish", async () => {
      if (res.statusCode < 500) {
        await writeAudit({
          req,
          action,
          resource,
          resourceId: req.params.id || null,
          success: res.statusCode < 400,
          details: {
            method: req.method,
            statusCode: res.statusCode
          }
        });
      }
    });

    next();
  };
}
