import { Router } from "express";
import { list } from "../controllers/audit.controller.js";
import { requireAdmin, requireSuperAdmin } from "../middleware/auth.js";

const router = Router();

router.get("/", requireAdmin, requireSuperAdmin, list);

export default router;
