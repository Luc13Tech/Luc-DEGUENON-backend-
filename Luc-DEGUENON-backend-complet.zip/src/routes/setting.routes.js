import { Router } from "express";
import { listPublic, listAdmin, upsert, remove } from "../controllers/setting.controller.js";
import { requireAdmin, requireSuperAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";

const router = Router();

router.get("/", listPublic);
router.get("/admin", requireAdmin, requireSuperAdmin, listAdmin);
router.put("/", requireAdmin, requireSuperAdmin, requireCsrf, upsert);
router.delete("/:key", requireAdmin, requireSuperAdmin, requireCsrf, remove);

export default router;
