import { Router } from "express";
import { getPublic, getAdmin, upsert } from "../controllers/profile.controller.js";
import { requireAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";

const router = Router();

router.get("/", getPublic);
router.get("/admin", requireAdmin, getAdmin);
router.put("/", requireAdmin, requireCsrf, upsert);

export default router;
