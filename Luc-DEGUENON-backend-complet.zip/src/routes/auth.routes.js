import { Router } from "express";
import { login, me, csrf, logout } from "../controllers/auth.controller.js";
import { authLimiter } from "../middleware/security.js";
import { requireAdmin, requireSuperAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";

const router = Router();

router.post("/login", authLimiter, login);
router.get("/me", requireAdmin, me);
router.get("/csrf", csrf);
router.post("/logout", requireAdmin, requireCsrf, logout);

export default router;
