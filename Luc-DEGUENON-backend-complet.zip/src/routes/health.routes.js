import { Router } from "express";
import { databaseReady } from "../config/database.js";

const router = Router();

router.get("/", (_req, res) => {
  res.json({
    ok: true,
    service: "Luc DEGUENON API",
    database: databaseReady() ? "connected" : "disconnected",
    timestamp: new Date().toISOString()
  });
});

export default router;
