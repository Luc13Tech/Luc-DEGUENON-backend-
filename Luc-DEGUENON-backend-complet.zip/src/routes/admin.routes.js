import { Router } from "express";
import { listAdmins, createAdmin, deactivateAdmin } from "../controllers/admin.controller.js";
import { requireAdmin, requireSuperAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";

const router = Router();

router.get("/", requireAdmin, requireSuperAdmin, listAdmins);
router.post("/", requireAdmin, requireSuperAdmin, requireCsrf, createAdmin);
router.patch("/:id/deactivate", requireAdmin, requireSuperAdmin, requireCsrf, deactivateAdmin);

export default router;
