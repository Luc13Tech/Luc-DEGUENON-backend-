import { Router } from "express";
import { list, upload, update, softDelete } from "../controllers/media.controller.js";
import { requireAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";
import { uploadImage } from "../middleware/upload.js";

const router = Router();

router.get("/", requireAdmin, list);
router.post("/", requireAdmin, requireCsrf, uploadImage, upload);
router.patch("/:id", requireAdmin, requireCsrf, update);
router.delete("/:id", requireAdmin, requireCsrf, softDelete);

export default router;
