import { Router } from "express";
import { listPublic, listAdmin, create, update, softDelete, restore } from "../controllers/project.controller.js";
import { requireAdmin } from "../middleware/auth.js";
import { requireCsrf } from "../middleware/security.js";

const router = Router();

router.get("/", listPublic);
router.get("/admin", requireAdmin, listAdmin);
router.post("/", requireAdmin, requireCsrf, create);
router.patch("/:id", requireAdmin, requireCsrf, update);
router.delete("/:id", requireAdmin, requireCsrf, softDelete);
router.patch("/:id/restore", requireAdmin, requireCsrf, restore);

export default router;
